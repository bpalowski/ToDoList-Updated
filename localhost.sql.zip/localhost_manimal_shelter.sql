-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 11, 2018 at 11:18 PM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manimal_shelter`
--
DROP DATABASE IF EXISTS `manimal_shelter`;
CREATE DATABASE IF NOT EXISTS `manimal_shelter` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `manimal_shelter`;

-- --------------------------------------------------------

--
-- Table structure for table `mans`
--

DROP TABLE IF EXISTS `mans`;
CREATE TABLE IF NOT EXISTS `mans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tigers`
--

DROP TABLE IF EXISTS `tigers`;
CREATE TABLE IF NOT EXISTS `tigers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tigers`
--

INSERT INTO `tigers` (`id`, `name`, `gender`, `age`) VALUES
(1, 'Fuzzy', 'Male', 12),
(2, 'Maude', 'Female', 15),
(3, 'Fuzzy', 'Male', 12),
(4, 'Maude', 'Female', 15),
(5, 'Fuzzy', 'Male', 12),
(6, 'Maude', 'Female', 15),
(7, 'Fuzzy', 'Male', 12),
(8, 'Maude', 'Female', 15),
(9, 'Fuzzy', 'Male', 12),
(10, 'Maude', 'Female', 15),
(11, 'Fuzzy', 'Male', 12),
(12, 'Maude', 'Female', 15),
(13, 'Fuzzy', 'Male', 12),
(14, 'Maude', 'Female', 15);

-- --------------------------------------------------------

--
-- Table structure for table `warthogs`
--

DROP TABLE IF EXISTS `warthogs`;
CREATE TABLE IF NOT EXISTS `warthogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
